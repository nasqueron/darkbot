#! /bin/sh

# Clean up after previous compile.
rm -rf $HOME/darkbot
rm -rf build
